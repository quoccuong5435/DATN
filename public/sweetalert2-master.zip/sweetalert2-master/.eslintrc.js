module.exports = {
  extends: [
    '@sweetalert2/eslint-config'
  ],
  rules: {
    'import/extensions': ['error', 'always'],
  }
}
